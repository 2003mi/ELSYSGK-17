l = list(range(70))

nl = []

for i in range