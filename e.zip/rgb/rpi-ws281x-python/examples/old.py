import math
import time
from rpi_ws281x import PixelStrip, Color
import argparse
import strandtestc as s
import random
import json
import os
import RPi.GPIO as GPIO

button = 23
GPIO.setmode(GPIO.BCM) 
GPIO.setup(button, GPIO.IN, pull_up_down=GPIO.PUD_UP)

path = os.path.dirname(os.path.realpath(__file__))
SETTINGFILE = path+"/settings.json"

maptemplate = ([5],list(range(6,71)),list(range(0,5)))
MAP = []
for i in maptemplate:
    for j in i:
        MAP.append(j)   

def readState():
    return bool(GPIO.input(button))
     


# LED strip configuration:
LED_COUNT = 70        # Number of LED pixels.
LED_PIN = 18          # GPIO pin connected to the pixels (18 uses PWM!).
# LED_PIN = 10        # GPIO pin connected to the pixels (10 uses SPI /dev/spidev0.0).
LED_FREQ_HZ = 800000  # LED signal frequency in hertz (usually 800khz)
LED_DMA = 10          # DMA channel to use for generating signal (try 10)
LED_BRIGHTNESS = 255  # Set to 0 for darkest and 255 for brightest
LED_INVERT = False    # True to invert the signal (when using NPN transistor level shift)
LED_CHANNEL = 0       # set to '1' for GPIOs 13, 19, 41, 45 or 53
side = 6

numer = math.floor(LED_COUNT/side)

SIDES = {}
offset = 0
for i in range(side):
    SIDES[i] = list(range((numer*i)+offset,(numer*(i+1))+offset))

SIDES = {
    0: [64,65,66,67,68,69,70,0,1,2,3,4],
    1: list(range(5,17)),
    2: list(range(17,29)),
    3: list(range(29,40)),
    4: list(range(40,52)),
    5: list(range(52,64)),
}

def colorWipeI(strip, color):
    """Wipe color across display a pixel at a time."""
    for i in range(strip.numPixels()):
        strip.setPixelColor(i, color)
    strip.show()

def setSideColor(strip, side, color):
    for i in side:
        strip.setPixelColor(i, color)
    strip.show()

def setRandom(strip, color=False, wait_ms=50, c=False):
    l = list(range(strip.numPixels()))
    if not color:
        while True:
            r = random.randint(0,50)
            g = random.randint(0,150)
            b = random.randint(0,255)
            led = random.choice(l)
            strip.setPixelColor(led, Color(r,g,b))
            strip.show()
            time.sleep(wait_ms / 1000.0)
    elif c:
        while True:
            for led in range(strip.numPixels()):
                colo = random.choice(color)
                strip.setPixelColor(led, colo)
            strip.show()
            time.sleep(wait_ms / 1000.0)            
    else:
        for led in range(strip.numPixels()):
            colo = random.choice(color)
            strip.setPixelColor(led, colo)
        strip.show()
        while True:
            colo = random.choice(color)
            led = random.choice(l)
            strip.setPixelColor(led, colo)
            strip.show()
            time.sleep(wait_ms / 1000.0)

def sideWheel(strip, side, color, wait_ms=50):
    while len(color) < len(SIDES):
        color.append(Color(0,0,0))
    for i in range(len(SIDES)):
        setSideColor(strip, SIDES[i], color[i])
    lis = []
    for i, val in side.items():
        lis.append(val[-1])
        #strip.setPixelColor(i, color)
        #strip.show()
        #time.sleep(wait_ms / 1000.0)
    while True:
        for i in range(len(lis)):
            strip.setPixelColor(lis[i], color[i])
            if lis[i] < 72:
                lis[i] += 1
            else:
                lis[i] = 0
        strip.show()
        time.sleep(wait_ms / 1000.0)

strip = PixelStrip(LED_COUNT, LED_PIN, LED_FREQ_HZ, LED_DMA, LED_INVERT, LED_BRIGHTNESS, LED_CHANNEL)
# Intialize the library (must be called once before other functions).
strip.begin()
#colorWipeI(strip, Color(255, 0, 0))
#setSideColor(strip, SIDES[1], Color(0, 255, 0))
    


r = ''
with open(SETTINGFILE, "r") as file:
    r = file.read()
data = json.loads(r)

for i in range(len(data["dark blue"])):
    data["dark blue"][i][0] = 10

for i in data:
    for j in range(len(data[i])):
        a = data[i][j]
        data[i][j] = Color(a[0], a[1], a[2])

testColor = (Color(0, 0, 255), Color(0, 255, 0), Color(0, 255, 255), Color(255, 0, 0), Color(255, 0, 255), Color(255, 255, 0))

#sideWheel(strip, SIDES, color=testColor)
for i in SIDES:
    setSideColor(strip, SIDES[i], testColor[i])


#while True:
    #s.rainbow(strip)
    #s.rainbowCycle(strip)
    #s.theaterChaseRainbow(strip)
#setRandom(strip, color=testColor)

#setRandom(strip)
#s.rainbowCycle(strip)

#setRandom(strip, color=testColor, c=True, wait_ms=10)

w = 0
z = 0
max = strip.numPixels()
# while True:
#     if w > 0:
#         strip.setPixelColor(MAP[w-1], Color(0,0,0))
#     if w == 0: 
#         strip.setPixelColor(max, Color(0,0,0))
#     strip.setPixelColor(w, s.wheel(z))
#     strip.show()
#     time.sleep(20 / 1000.0)
#     if z < 255:
#         z +=1
#     else:
#         z = 0
#     if w < max:
#         w +=1
#     else:
#         w = 0

colorWipeI(strip, Color(0,0,0))

while True:
    print(readState())


# print(MAP)
# for led in range(strip.numPixels()+1):
#     strip.setPixelColor(MAP[led], s.wheel(led))
#     print(MAP[led],led)
#     strip.show()
