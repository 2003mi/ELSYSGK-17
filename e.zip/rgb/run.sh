#!/usr/bin/bash  
screen -dm bash -c "/home/pi/rgb/start.sh; exec sh"
