#!/usr/bin/bash  
echo "hello world :)"
cd /home/pi/rgb/rpi-ws281x-python/examples/
python3 ./main.py


